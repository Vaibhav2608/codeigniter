<script type="text/html" id="tmpl-attachment-details-focal-point">
	<div class="image-focal">
		<div class="image-focal__wrapper">
			<div class="image-focal__point"></div>
			<div class="image-focal__clickarea"></div>
		</div>
	</div>
</script>