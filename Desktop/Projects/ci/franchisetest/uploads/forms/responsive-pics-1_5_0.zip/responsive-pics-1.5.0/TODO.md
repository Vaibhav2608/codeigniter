
* Limit api usage with `sizes` presets to prevent abuse
* Enable more crop functionality by switching to $wp_editor->crop instead of $wp_editor->resize
* Improve `add_missing_breakpoints` when there are custom breakpoints defined