<?php

namespace Mpdf\Tag;

class Ins extends InlineTag
{


}
