<?php

namespace Mpdf\Tag;

class SetPageHeader extends SetHtmlPageFooter
{


}
